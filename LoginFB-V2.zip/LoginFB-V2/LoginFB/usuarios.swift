//
//  usuarios.swift
//  LoginFB
//
//  Created by Eduardo Quintero on 23/11/18.
//  Copyright © 2018 Germán Santos Jaimes. All rights reserved.
//

import Foundation
import UIKit

struct User {
    var name: String
    var email: String
    init(name:String, email:String) {
        self.name = name
        self.email = email
    }

}
