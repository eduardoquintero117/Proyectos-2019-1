//
//  LoginAccountViewController.swift
//  LoginFB
//
//  Created by Germán Santos Jaimes on 11/7/18.
//  Copyright © 2018 Germán Santos Jaimes. All rights reserved.
//

import UIKit
import Firebase

class LoginAccountViewController: UIViewController, UITableViewDelegate, UITableViewDataSource{
    
    private var baseDeDatos = [User]()

    @IBOutlet weak var tabla: UITableView!
    
    @IBOutlet weak var nombre: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.isNavigationBarHidden = true
        // Do any additional setup after loading the view.
        
        tabla.delegate = self
        tabla.dataSource = self
        Firestore.firestore().collection("users").addSnapshotListener{ (snapshot, error) in
            if let error = error{
                debugPrint(error)
            }else{
                self.baseDeDatos.removeAll()
                for document in (snapshot?.documents)!{
                    
                    //print(document.data())
                    let data = document.data()
                    let nametemp = data["username"] as! String
                    let emailtemp = data["email"] as! String
                    //print(nametemp)
                    print(emailtemp)
                    let newElement = User(name: nametemp, email: emailtemp)
                    self.baseDeDatos.append(newElement)
                    if (emailtemp == Auth.auth().currentUser?.email ){
                        self.nombre.text = nametemp
                    }
                   
                }
                self.tabla.reloadData()
            }
        
        }
        
        
        
        //
        
        
    }
    
   // override func viewWillAppear(_ animated: Bool) {}
    
    
    @IBAction func logoutUser(_ sender: UIButton) {
        //navigationController?.popViewController(animated: true)
        do {
            try Auth.auth().signOut()
        } catch let  logoutError  {
            print(logoutError)
        }
        
        navigationController?.popViewController(animated: true)
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.baseDeDatos.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "celda", for: indexPath) as! customTableViewCell
        cell.nameUser.text = baseDeDatos[indexPath.row].name
        cell.emailUser.text = baseDeDatos[indexPath.row].email
       return cell
    }
    
    
}
